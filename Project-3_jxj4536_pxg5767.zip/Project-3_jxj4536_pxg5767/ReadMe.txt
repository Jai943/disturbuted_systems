Code is done in Python 3.9.7
__________________________________________________________________________________________________
Instructions for execution:

Use the following commands in the command prompt to run the code.

to start Coordinator - test.py in first terminal
>python test.py

to start Node - Node.py in second terminal (run it parallel when test.py is running)
>python Node.py 

Note :- you can run 'n' nodes in different terminals, with the same command(>python Node.py), it will be your 2nd,3rd....nth node
___________________________________________________________________________________________________
example for execution

in first terminal

>python test.py

open a new terminal every-time run different Nodes 

>python Node.py

___________________________________________________________________________________________________


