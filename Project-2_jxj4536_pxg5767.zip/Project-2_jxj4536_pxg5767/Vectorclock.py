
class Vectorclock:
    deviceXTime = 10
    deviceYTime = 100
    deviceZTime = 1000

    def getDeviceXTime(self):
        return self.deviceXTime

    def getDeviceYTime(self):
        return self.deviceYTime

    def getDeviceZTime(self):
        return self.deviceZTime