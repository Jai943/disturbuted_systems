Code is done in Python 3.9.7
__________________________________________________________________________________________________
Instructions for execution:

Note :- first, we need to start all 3 server's (devices) to send/receive messages between devices

___________________________________________________________________________________________________

example for execution to start servers

in first terminal run deviceX (first server) server

>python DeviceX.py 

and in second terminal run deviceY (second server) server 

>python DeviceY.py

and in third terminal run deviceZ (third server) server 

>python DeviceZ.py  

___________________________________________________________________________________________________

Sample execution after starting the server:-----------


Enter message : #enter randomn message that you want to send

Enter Device Number to send (X:1,Y:2,Z:3) : 1

Before device X Receiving a Message
[10, 100, 1000]
After device X Receiving a Message - message:  #enter randomn message that you want to send
[11, 100, 1000]