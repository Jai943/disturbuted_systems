Project-1
Part-1 Instructions:
----------------------------------------------------------------------------------------------------------------------------------------------------
Programming language = Python 3.0 or higher needed
Socket programming in python is used 

-------------------------------------------------------------------------------------------------------------------------------------------------------
Please install below Packages required(ignore if already present):

pip install python-socketio

There are two files:
client.py
server.py
-------------------------------------------------------------------------------------------------------------------------------------------------------
Executing the program:

-> Open terminal or powershell in your laptop and go to the program part-1 directory
-> In terminal enter the following to run server
		python server.py
-> Then open another powershell(or terminal) and run the client program with arguments
	note: the file file.txt is for reference and is saved in the folder and you can try with any file and it should be placed in the part-1 folder	
	for Upload operation:
				python client.py upload file.txt
	for download operation:
				python client.py download file.txt
	for rename operation:
				python client.py rename file.txt test.txt
	for delete operation:
				python client.py delete test.txt


